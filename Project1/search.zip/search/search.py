# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()

def solveAlg(problem, stack):

    if stack.isEmpty():
        raise ValueError('This stack is empty!')

    #if problem.isGoalState(stack[len(stack) - 1]):
def getActions(stack):

    result = []

    for s in stack.list[1:]:
        result.append(s[1])

    return result

def checkVisit(lista,item):

    if item in lista:
        return True

    return False

def recAlg(problem, stack, check):

    if problem.isGoalState(stack.list[len(stack.list) - 1][0]): 
        global globalvar
        globalvar = util.Stack()
        globalvar = getActions(stack)
        return globalvar

    if not checkVisit(check,stack.list[len(stack.list) - 1][0]) == True:

        check.append(stack.list[len(stack.list) - 1][0])

        succesors = []
        succesors = problem.getSuccessors(stack.list[len(stack.list) - 1][0])

        for s in succesors:
            newStack = util.Stack()
            newStack.list = stack.list[:]
            newStack.push(s)
            return recAlg(problem, newStack, check)
            ##if listed:
                ##return listed

    #return []

def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def algBF(problem,stack,moves):

    nodelist = []
    stack.push((problem.getStartState(),[],[]))
    moves.push([])

    while not stack.isEmpty():
        actual = stack.pop()
        actual2 = moves.pop()
        node, actions, cost = actual

        if problem.isGoalState(node):
            return actual2

        if not checkVisit(nodelist,node):
            nodelist.append(node)
            for node, actions, cost in problem.getSuccessors(node):
                stack.push((node,actions,cost))
                moves.push(actual2 + [actions])

#Nota: guardamos movimientos y nodos en stacks diferentes, pero el resultado es el mismo (es para tenerlo mas organizado)
def depthFirstSearch(problem):

    stack = util.Stack()
    moves = util.Stack()
    result = algBF(problem,stack,moves)
    return result

def breadthFirstSearch(problem):

    stack = util.Queue()
    moves = util.Queue()
    result = algBF(problem,stack,moves)
    return result

def uniformCostSearch(problem):

    nodelist = []
    cola = util.PriorityQueue()
    moves = util.PriorityQueue()
    cola.push([(problem.getStartState(),[],[]),0,[]],0)
    moves.push([],0)

    while not cola.isEmpty():
        actual = cola.pop()
        actual2 = moves.pop()
        node, actions, cost = actual[0]

        if problem.isGoalState(node):
            #return actual[2]
            return actual2
        
        if not checkVisit(nodelist,node):
            nodelist.append(node)
            for _node, _actions, _cost in problem.getSuccessors(node):
                cola.push([(_node,_actions,_cost),actual[1] + _cost, actual[2] + [_actions]], actual[1] + _cost)
                moves.push(actual2 + [_actions],actual[1] + _cost)
        

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    
    nodelist = []
    cola = util.PriorityQueue()
    moves = util.PriorityQueue()
    startValue = heuristic(problem.getStartState(),problem)
    cola.push([(problem.getStartState(),[],[]),startValue,[]],startValue)
    moves.push([],startValue)

    while not cola.isEmpty():
        actual = cola.pop()
        actual2 = moves.pop()
        node, actions, cost = actual[0]

        if problem.isGoalState(node):
            #return actual[2]
            return actual2

        if not checkVisit(nodelist,node):
            nodelist.append(node)
            for _node, _actions, _cost in problem.getSuccessors(node):
                cola.push([(_node,_actions,_cost),actual[1] + _cost, actual[2] + [_actions]], actual[1] + _cost + heuristic(_node,problem))
                moves.push(actual2 + [_actions],actual[1] + _cost + heuristic(_node,problem))

# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
